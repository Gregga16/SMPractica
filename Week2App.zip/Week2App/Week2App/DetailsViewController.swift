//
//  DetailsViewController.swift
//  Week2App
//
//  Created by Fhict on 03/03/16.
//  Copyright © 2016 Gregory Lammers. All rights reserved.
//

import Foundation

import UIKit

class DetailsViewController : UIViewController {
    
}