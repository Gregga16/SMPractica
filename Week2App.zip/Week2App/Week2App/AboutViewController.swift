//
//  AboutViewController.swift
//  Week2App
//
//  Created by Fhict on 03/03/16.
//  Copyright © 2016 Gregory Lammers. All rights reserved.
//

import Foundation

import UIKit

class AboutViewController : UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBOutlet weak var textfieldBeShown: UITextField!
    
    @IBAction func ShowtextField(sender: UIButton) {
        var alertView = UIAlertView( title: "Your text is:", message: textfieldBeShown.text, delegate: nil, cancelButtonTitle: "Done!")
        
        alertView.show()
    }
}