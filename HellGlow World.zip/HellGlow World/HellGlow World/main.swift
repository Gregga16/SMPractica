//
//  main.swift
//  HellGlow World
//
//  Created by Fhict on 26/02/16.
//  Copyright © 2016 Gregory Lammers. All rights reserved.
//

import Foundation

var blueLightAct = GlowAct()
blueLightAct.name = "The Bluelight act"
blueLightAct.startTime = "22:20"
blueLightAct.rating = 8

var redLightAct = GlowAct()
redLightAct.name = "The RedLight act"
redLightAct.startTime = "18:00"
redLightAct.rating = 7

//blueLightAct.showInfo()

var blueLigtAct = City()
blueLigtAct.name = "Eindhoven"
blueLigtAct.population = 220000
blueLigtAct.glowActs.append(blueLightAct)
blueLigtAct.glowActs.append(redLightAct)

blueLigtAct.showInfo()

